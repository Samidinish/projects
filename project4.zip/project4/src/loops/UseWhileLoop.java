package loops;

public class UseWhileLoop {

	public static void main(String[] args) {
		
		int num = 0;
		while(num<5){
			System.out.println(num);
			num++;
		}

	}

}
