package loops;

public class UseDoWhileLoop {

	public static void main(String[] args) {
		int num = 1;
		do{
			System.out.println("This is second week of the course");
		}while(num<0);
	}
}
