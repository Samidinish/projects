package finalvariable;

public class DriveWay {
	
	 final static int driveWaySize = 10;
	
	

}
