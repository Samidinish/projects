package superkeyword;

public class TestCar {

	public static void main(String[] args) {
		ModernCar teslaEconomyModel = new ModernCar("model 3");
		teslaEconomyModel.fuelType();
		System.out.println(teslaEconomyModel.run);
		
		

	}

}
