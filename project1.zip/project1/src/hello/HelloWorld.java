package hello;

public class HelloWorld {
   //Main method start here
	public static void main(String[] args) {
		System.out.println("Hello Java ! Hello WOrld !");
		int number1 = 10;
		int number2 = 15;
		
		int total = number1 + number2;
		System.out.println(total);

	}
}
