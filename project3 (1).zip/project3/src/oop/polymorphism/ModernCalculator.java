package oop.polymorphism;

public class ModernCalculator extends AreaOfLand{
	
	public int calculateLandSize(int a, int b, int c){
		int total = a + b - 2;
		return total;
	}

}
