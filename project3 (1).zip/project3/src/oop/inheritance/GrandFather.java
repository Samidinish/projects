package oop.inheritance;

public class GrandFather extends GreatGrandFather{
	
	public void heights(){
		System.out.println("Grand father is 6 feet");
	}

}
