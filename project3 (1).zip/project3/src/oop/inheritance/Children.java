package oop.inheritance;

public class Children extends Father{
	
	

}
