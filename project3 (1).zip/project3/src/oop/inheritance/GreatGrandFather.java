package oop.inheritance;

public class GreatGrandFather {
	
	public void skinColor(){
		System.out.println("brown and chocolate skin color");
	}

}
