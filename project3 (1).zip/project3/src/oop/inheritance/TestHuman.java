package oop.inheritance;

public class TestHuman {

	public static void main(String[] args) {
		Children child1 = new Children();
		child1.eyeColor();
		child1.heights();
		child1.skinColor();

	}

}
