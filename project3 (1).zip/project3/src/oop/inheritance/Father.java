package oop.inheritance;

public class Father extends GrandFather{
	
	public void hairColor(){
		System.out.println("Father has brown hair color");
	}
	
	public void eyeColor(){
		System.out.println("Father has green eye color");
	}

}
