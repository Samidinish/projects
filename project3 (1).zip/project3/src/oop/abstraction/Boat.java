package oop.abstraction;

public interface Boat {

}
