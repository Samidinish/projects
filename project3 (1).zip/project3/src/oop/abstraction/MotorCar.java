package oop.abstraction;

public abstract class MotorCar {
	
	public void buildEngine(){
		System.out.println("Let's implement the engine");
	}
	
	public abstract void drive();
	

}
