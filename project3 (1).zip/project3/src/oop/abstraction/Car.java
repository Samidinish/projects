package oop.abstraction;

public interface Car {


	public void carShape();
	
	public void start();
	
	public void stop();
	
	
}
