package staticvariable;

public class DriveWay {
	public int driveWaySize;
	
	public void showDriveWaySize(){
		System.out.println(driveWaySize);
	}

}
