package classNobject;

public class Office {
	
	public void myOfficeSpace(){
		System.out.println("PeopleNTech Office is located on 32-72 steinway street");
	}

}
